# whatsapp-bot
MVP disparador de mensagens via facebook API + lambda AWS.

obs: template.dev.yml deve ser ajustado conforme suas variaveis de ambiente seja.

# iniciando projeto localhost.

- inicie o docker

- npm start


# iniciando projeto lambda.

- zipe o projeto.

- despacha o zip em sua lambda.

obs: ainda não tem pipe.